# About

Projects demonstrate perspective pojection algorithm implementation from 3D co-ordinates space to 2D screen co-ordinates. 
Program is written in C# windows form application, detail of project is in http://www.codeincodeblock.com/2012/03/projecting-3d-world-co-ordinates-into.html
