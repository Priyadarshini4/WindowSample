# About

Projects demonstrate z-buffer algorithm implementation for visible surface detection. 
Program is written in C# windows form application, detail of project is in http://www.codeincodeblock.com/2012/04/visible-surface-detection-z-buffer.html
