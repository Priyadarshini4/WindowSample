﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Graphics3Dto2D
{
    class Coefficient_Of_Plane
    {
        public double A, B, C, D;
        public Coefficient_Of_Plane()
        {
            A = B = C = D = 0;
        }
    }
}
