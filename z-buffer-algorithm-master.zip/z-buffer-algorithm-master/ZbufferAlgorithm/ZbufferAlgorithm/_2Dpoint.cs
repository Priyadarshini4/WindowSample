﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graphics3Dto2D
{
    class _2Dpoint
    {
        public int h, v;
        public _2Dpoint(int hh, int vv)
        {
            h = hh;
            v = vv;
        }

        public _2Dpoint()
        {
            // TODO: Complete member initialization
            h = 0;
            v = 0;
        }
    }
}
